<template>
  <div class="homepage">
    <h1>Новости</h1>
    <SearchBar @search="handleSearch" />
    <SortBar @sort="handleSort" />
    <NewsList :news="filteredNews" />
    <p v-if="news.length === 0">Нет доступных новостей</p>
  </div>
</template>

<script>
import NewsList from "@/components/NewsList.vue";
import SearchBar from "@/components/SearchBar.vue";
import SortBar from "@/components/SortBar.vue";

export default {
  components: {
    NewsList,
    SearchBar,
    SortBar,
  },
  data() {
    return {
      news: [],
      searchQuery: "",
      sortCriteria: "",
    };
  },
  computed: {
    filteredNews() {
      let filtered = this.news.filter((newsItem) => {
        return (
          newsItem.title.toLowerCase().includes(this.searchQuery.toLowerCase()) ||
          newsItem.anons.toLowerCase().includes(this.searchQuery.toLowerCase())
        );
      });

      if (this.sortCriteria) {
        if (this.sortCriteria === "alphabetAsc") {
          filtered.sort((a, b) => a.title.localeCompare(b.title));
        } else if (this.sortCriteria === "alphabetDesc") {
          filtered.sort((a, b) => b.title.localeCompare(a.title));
        } else if (this.sortCriteria === "dateAsc") {
          filtered.sort((a, b) => new Date(a.date) - new Date(b.date));
        } else if (this.sortCriteria === "dateDesc") {
          filtered.sort((a, b) => new Date(b.date) - new Date(a.date));
        }
      }
      return filtered;
    },
  },
  mounted() {
    fetch("http://127.0.0.1:8000/api/news/")
      .then((response) => response.json())
      .then((data) => {
        this.news = data;
      })
      .catch((error) => {
        console.error("Ошибка загрузки новостей:", error);
      });
  },
  methods: {
    handleSearch(query) {
      this.searchQuery = query;
    },
    handleSort(criteria) {
      this.sortCriteria = criteria;
    },
  },
};
</script>

<style scoped>
.homepage {
  padding: 20px;
}
</style>
