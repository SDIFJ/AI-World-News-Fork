<template>
  <div v-if="newsItem" class="news-page">
    <h1>{{ newsItem.title }}</h1>
    <p><strong>{{ formatDate(newsItem.date) }}</strong></p>
    <p>{{ newsItem.full_text }}</p>
    <a href="/">Вернуться на главную</a>
  </div>
  <div v-else>
    <p>Загрузка...</p>
  </div>
</template>

<script>
export default {
  data() {
    return {
      newsItem: null,
    };
  },
  methods: {
    formatDate(date) {
      const options = { year: "numeric", month: "long", day: "numeric", hour: "2-digit", minute: "2-digit" };
      return new Date(date).toLocaleString("ru-RU", options); // Локализация для русского языка
    },
  },
  mounted() {
    const newsId = this.$route.params.id;
    fetch(`http://127.0.0.1:8000/api/news/${newsId}/`)
      .then((response) => response.json())
      .then((data) => {
        this.newsItem = data;
      })
      .catch((error) => {
        console.error("Ошибка загрузки новости:", error);
      });
  },
};
</script>
