<template>
  <div class="search-bar">
    <input
      type="text"
      v-model="searchQuery"
      @input="onSearch"
      placeholder="Поиск по новостям..."
    />
  </div>
</template>

<script>
export default {
  data() {
    return {
      searchQuery: "", // Запрос поиска
    };
  },
  methods: {
    // Когда пользователь вводит текст, отправляем запрос на поиск в родительский компонент
    onSearch() {
      this.$emit("search", this.searchQuery);
    },
  },
};
</script>

<style scoped>

</style>
