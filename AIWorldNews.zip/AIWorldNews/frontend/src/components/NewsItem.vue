<template>
  <div class="news-item">
    <h2>{{ news.title }}</h2>
    <p>{{ news.anons }}</p>
    <p><strong>{{ news.date }}</strong></p>
    <a :href="'/news/' + news.id">Читать далее</a>
  </div>
</template>

<script>
export default {
  props: {
    news: {
      type: Object,
      required: true,
    },
  },
};
</script>