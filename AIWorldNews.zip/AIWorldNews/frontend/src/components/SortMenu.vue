document.addEventListener("DOMContentLoaded", () => {
    const sortButton = document.getElementById("sort-button");
    const sortMenu = document.getElementById("sort-menu");
    const sortOptions = document.querySelectorAll(".sort-option");
  
    // Показать/скрыть меню при нажатии на кнопку
    sortButton.addEventListener("click", () => {
      sortMenu.classList.toggle("hidden");
    });
  
    // Закрытие меню при клике вне области
    document.addEventListener("click", (event) => {
      if (!event.target.closest(".sort-container")) {
        sortMenu.classList.add("hidden");
      }
    });
  
    // Выбор параметра сортировки
    sortOptions.forEach((option) => {
      option.addEventListener("click", (event) => {
        const sortValue = event.target.dataset.sort;
        console.log(Выбрана сортировка: ${sortValue});
        // Здесь можно вызвать функцию сортировки данных
        sortMenu.classList.add("hidden");
      });
    });
  });