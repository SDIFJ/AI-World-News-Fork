<template>
  <div class="sort-bar">
    <button @click="toggleDropdown">Сортировка</button>
    <div v-if="isDropdownVisible" class="dropdown">
      <button @click="sort('alphabetAsc')">Сортировка по алфавиту ↑</button>
      <button @click="sort('alphabetDesc')">Сортировка по алфавиту ↓</button>
      <button @click="sort('dateAsc')">Сортировка по дате ↑</button>
      <button @click="sort('dateDesc')">Сортировка по дате ↓</button>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      isDropdownVisible: false, // Показывать/скрывать меню
    };
  },
  methods: {
    // Открытие/закрытие выпадающего меню
    toggleDropdown() {
      this.isDropdownVisible = !this.isDropdownVisible;
    },
    // Сортировка по выбранному критерию
    sort(criteria) {
      this.$emit("sort", criteria); // Передаем критерий сортировки в родительский компонент
      this.isDropdownVisible = false; // Закрыть меню после выбора
    },
  },
};


</script>

<style scoped>

</style>
