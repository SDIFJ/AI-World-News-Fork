<template>
  <div class="news-list">
    <div class="news-item" v-for="newsItem in news" :key="newsItem.id">
      <h2>{{ newsItem.title }}</h2>
      <p>{{ newsItem.anons }}</p>
      <p><strong>{{ formatDate(newsItem.date) }}</strong></p> <!-- Отображение даты в правильном формате -->
      <a :href="'/news/' + newsItem.id">Читать далее</a>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    news: {
      type: Array,
      required: true,
    },
  },
  methods: {
    // Метод для форматирования даты
    formatDate(date) {
      const formattedDate = new Date(date);
      return formattedDate.toLocaleString("ru-RU", {
        year: "numeric",
        month: "long",
        day: "numeric",
        hour: "numeric",
        minute: "numeric",
        hour12: false,
      });
    },
  },
};
</script>

<style scoped>
/* Добавьте стили по необходимости */
</style>
