import { createRouter, createWebHistory } from "vue-router";
import HomePage from "../views/HomePage.vue";
import NewsPage from "../views/NewsPage.vue";

const routes = [
  {
    path: "/",
    name: "Home",
    component: HomePage,
  },
  {
    path: "/news/:id",
    name: "News",
    component: NewsPage,
  },
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

export default router;
