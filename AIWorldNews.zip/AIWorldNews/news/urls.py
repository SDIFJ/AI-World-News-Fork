from django.urls import path
from .views import ArticlesListView, ArticlesDetailView

urlpatterns = [
    path('api/news/', ArticlesListView.as_view(), name='api_articles_list'),
    path('api/news/<int:pk>/', ArticlesDetailView.as_view(), name='api_articles_detail'),
]