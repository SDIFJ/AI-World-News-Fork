from rest_framework import generics
from .models import Articles
from .serializers import ArticlesSerializer
from django.shortcuts import render
from django.views.generic import DetailView

class ArticlesListView(generics.ListAPIView):
    queryset = Articles.objects.all()
    serializer_class = ArticlesSerializer

class ArticlesDetailView(generics.RetrieveAPIView):
    queryset = Articles.objects.all()
    serializer_class = ArticlesSerializer

def news_home(request):
    news = Articles.objects.all()
    return render(request, 'news/news_home.html', {'news': news})

class NewsDetailView(DetailView):
    model = Articles
    template_name = 'news/detail_view.html'
    context_object_name = 'post'